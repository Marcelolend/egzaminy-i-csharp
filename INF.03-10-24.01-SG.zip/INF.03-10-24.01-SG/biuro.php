<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <title>Poznaj Europę</title>
    <link rel="stylesheet" href="styl9.css">
</head>
<body>
   <header>
<h1>BIURO PODRÓŻY</h1>
   </header> 
   <aside>
<h2>Promocje</h2>

<table>
    <tr>
<td>Warszawa</td>
<td>od 600zł</td>
    </tr>
    <tr>
        <td>Wenecja</td>
        <td>od 1200zł</td>
            </tr>
            <tr>
                <td>Paryż</td>
                <td>od 1200zł</td>
                    </tr>
    

</table>
   </aside>
   <main>
<h2>W tym roku jedziemy do...</h2>
<?php
$db = mysqli_connect('localhost', 'root', '', 'podroze');
$q = 'SELECT nazwaPliku, podpis FROM `zdjecia` ORDER BY podpis;';
$result = mysqli_query($db,$q);

while($row = mysqli_fetch_array($result)){
   echo '<img src="'.$row['nazwaPliku'].'"  alt="'.$row['podpis'].'" title="'.$row['podpis'].'">';
}
?>
   </main>

   <aside>
<h2>Kontakt</h2>
<a href="mailto:biuro@wycieczki.pl">napisz do nas</a>
<p>telefon: 444555666</p>
   </aside>

   <section>
<h3>W poprzednich latach byliśmy...</h3>
<ol>
<?php
q = ;
$result = mysqli_query($db,$q);
echo '<li>Dnia <data> Pojechaliśmy '


?>
</ol>
   </section>

   <footer>
<p>Stronę wykonał: 010203040506070809</p>
   </footer>
</body>
</html>