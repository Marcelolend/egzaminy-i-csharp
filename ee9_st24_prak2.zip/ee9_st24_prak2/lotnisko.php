<!DOCTYPE html>
<?php
setcookie("user","test", time() + 7200, '/')
?>
<html lang="PL">
	<head>
		<meta charset="UTF-8">
		<title>Port Lotniczy</title>
		<link rel="stylesheet"  href="styl5.css">
	</head>
<html>
    <body>
       
<section id="baner1">
<img src="zad5.png" alt="logo lotnisko">
</section>

<section id="baner2">

<h1>Przyloty</h1>

</section>

<section id="baner3">

<h3>przydatne linki</h3>
<a href="kwerendy.txt">Pobierz...</a>

</section>

<main>
<table>
    <tr>
        <th>czas</th>
        <th>kierunek</th>
        <th>numer rejsu</th>
        <th>status</th>
</tr>

<?php

$db = mysqli_connect("localhost","root","","loty");

$q= 'SELECT czas, kierunek, nr_rejsu, status_lotu FROM przyloty ORDER BY czas';

$result= mysqli_query($db, $q);

while($row = mysqli_fetch_array($result)){
    echo '<tr>
    <td>'.$row["czas"].'</td>
    <td>'.$row["kierunek"].'</td>
    <td>'.$row["nr_rejsu"].'</td>
    <td>'.$row["status_lotu"].'</td>
    </tr>';
}

?>
    
</table>
</main>

<footer>
<section id="stopka">

<?php
   if(!isset($_COOKIE["user"])) {
    echo "<p><b>Dzień dobry! Strona lotniska używa ciasteczek</b></p>";
    } else{
        echo "<p><i>Witaj ponownie na stronie lotniska</i></p>";

        }
        ?>
   


</section>


<section id=stopka2>
    
    Autor: 010203040506070809

</section>
</footer>

    </body>
    </html>